# UFO-Tracker
An app to track, search, and submit UFO sightings using the MapQuest API
